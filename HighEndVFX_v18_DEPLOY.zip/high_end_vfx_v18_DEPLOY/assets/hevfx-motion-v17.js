(function(){
  'use strict';
  var reduced=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function all(sel,root){return Array.prototype.slice.call((root||document).querySelectorAll(sel));}
  function markMotion(){
    var groups=all('main > section, body > section, .work-head, .hevfx-capabilities-head, .media-heading, .about-cta, footer.footer');
    groups.forEach(function(group){
      var items=all('h1,h2,h3,.eyebrow,.kicker,.v16-kicker,.title,.v16-title,.lead,.desc,.copy,.v16-copy,p:not(:empty),.filters,.cta-box',group).filter(function(el){return !el.closest('article') && !el.hasAttribute('data-hevfx-motion');});
      items.slice(0,8).forEach(function(el,i){el.setAttribute('data-hevfx-motion',i<2?'':'soft');el.style.setProperty('--hevfx-delay',Math.min(i*55,275)+'ms');});
    });
    var cardSelectors='.v16-panel,.preview-card,.breakdown-media-card,.service-card,.hevfx-capability,#work .project';
    all(cardSelectors).forEach(function(el,i){if(!el.hasAttribute('data-hevfx-motion')){el.setAttribute('data-hevfx-motion','soft');el.style.setProperty('--hevfx-delay',(i%6)*55+'ms');}});
    all('.orange-line,.hevfx-orange-line,.v16-orange-line').forEach(function(el){el.classList.add('hevfx-motion-line');});
    all('.preview-video,.breakdown-media,.media-frame,.video-wrap,.work-media').forEach(function(el){el.setAttribute('data-hevfx-media','');});
  }
  function reveal(){
    var targets=all('[data-hevfx-motion],[data-hevfx-media],.hevfx-motion-line');
    if(reduced||!('IntersectionObserver' in window)){targets.forEach(function(el){el.classList.add('hevfx-in');});return;}
    var io=new IntersectionObserver(function(entries){entries.forEach(function(entry){if(entry.isIntersecting){entry.target.classList.add('hevfx-in');io.unobserve(entry.target);}});},{threshold:.08,rootMargin:'0px 0px -5% 0px'});
    targets.forEach(function(el){io.observe(el);});
  }
  function headerState(){
    var ticking=false;
    function update(){document.body.classList.toggle('hevfx-scrolled',window.scrollY>28);ticking=false;}
    window.addEventListener('scroll',function(){if(!ticking){requestAnimationFrame(update);ticking=true;}},{passive:true});update();
  }
  function pointerGlow(){
    if(reduced||!window.matchMedia('(hover:hover) and (pointer:fine)').matches)return;
    var x=innerWidth/2,y=innerHeight/2,tx=x,ty=y,raf=0;
    function draw(){x+=(tx-x)*.14;y+=(ty-y)*.14;document.documentElement.style.setProperty('--hevfx-mx',x+'px');document.documentElement.style.setProperty('--hevfx-my',y+'px');if(Math.abs(tx-x)+Math.abs(ty-y)>.2)raf=requestAnimationFrame(draw);else raf=0;}
    window.addEventListener('pointermove',function(e){tx=e.clientX;ty=e.clientY;document.body.classList.add('hevfx-pointer-active');if(!raf)raf=requestAnimationFrame(draw);},{passive:true});
    document.documentElement.addEventListener('mouseleave',function(){document.body.classList.remove('hevfx-pointer-active');});
  }
  function heroDepth(){
    if(reduced)return;
    var hero=document.querySelector('.hevfx-hero,.hero');
    if(!hero)return;
    var media=hero.querySelector('.hevfx-media,.hero-media,video,iframe');
    var word=hero.querySelector('.hevfx-wordmark,h1,.hero-title');
    var ticking=false;
    function update(){var r=hero.getBoundingClientRect();var p=Math.max(0,Math.min(1,-r.top/Math.max(r.height,1)));if(media)media.style.transform='translate3d(0,'+(p*18)+'px,0) scale('+(1+p*.018)+')';if(word)word.style.transform='translate3d(0,'+(p*-8)+'px,0)';ticking=false;}
    window.addEventListener('scroll',function(){if(!ticking){requestAnimationFrame(update);ticking=true;}},{passive:true});update();
  }
  document.addEventListener('DOMContentLoaded',function(){
    markMotion();
    document.body.classList.add('hevfx-motion-ready');
    requestAnimationFrame(function(){reveal();headerState();pointerGlow();heroDepth();});
  });
})();
